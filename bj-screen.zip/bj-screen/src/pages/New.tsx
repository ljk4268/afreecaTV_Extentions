import Editor from '../components/Editor'

const New = () => {
  return <div style={{width: '100%'}}>
    <Editor />
  </div>
}

export default New
