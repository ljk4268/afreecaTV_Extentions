/// <reference types="react-scripts" />

var extensionSDK : any

    interface Window {
        AFREECA: any;
    }
